This programme break into several class templates and classes, namely hashtable, deque, student, course, courseSelect, utility and record. They will be described below:

Hashtable: It is a hashtable template making use of the deque template to store array of student and course objects deque.

Deque: It is a doubly linked-list implemented by student, course and courseSelect objects

Student: Contain student id, name, year and gender.

Course: Contain course code, name and credit.

CourseSelect: Contain student id, course code and mark.

Utility: Used to store the hashtables and turn into html file output.

Record: Used to store the hashtables and turn into database. Can perform save and load actions.